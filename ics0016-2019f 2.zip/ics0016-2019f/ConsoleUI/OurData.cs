/*namespace ConsoleUI
{
    public class OurData
    {
        public int xPos { get; set; }
        public int yPos { get; set; }
        public string value { get; set; }
    }
}*/