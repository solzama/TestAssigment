﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using Newtonsoft.Json;
using ConsoleUI;
using DAL;
using GameEngine;
using MenuSystem;

namespace ConsoleApp
{
    class Program
    {
        private static GameSettings _settings = new GameSettings();
        private CellState[,] ?  Board { get; set; }
        static void Main(string[] args)
        {
            var dbOption = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite("Data Source=/Users/sashazamana17/UniStudies/C#2019/ics0016-2019f/WebConnect4/connect4.db").Options;
           
            SetDefaultSettings();
            Console.Clear();

            Console.WriteLine($"Hello to {_settings.GameName}!");
            Console.WriteLine();
            
            var savedGamesMenu = new Menu(1)
            {
                Title = $"Choose the {_settings.GameName} game to continue with",
                MenuItemsDictionary = new Dictionary<string, MenuItem>()
            };
            
            List<string> savedGames = new List<string>();
            
            using (var ctx = new AppDbContext(dbOption))
            {
                foreach (var gameSave in ctx.GameSettingses
                    .Where(g => g.GameSettingsId != 1))
                {
                    if (gameSave.SaveName != null) {savedGames.Add(gameSave.SaveName);}
                }
            };

            int i = 1;
            foreach (var save in savedGames)
            {
                savedGamesMenu.MenuItemsDictionary.Add($"{i}", new MenuItem() { Title = save, CommandToExecute = () 
                        =>
                    {
                        _settings = LoadSavedGame(save);
                        return TestGame();
                    }
                });
                i++;
            }

            var gameMenu = new Menu(1)
            {
                Title = $"Start a new game of {_settings.GameName}",
                MenuItemsDictionary = new Dictionary<string, MenuItem>()
                {
                    {
                        "S", new MenuItem()
                        {
                            Title = "Start the game",
                            CommandToExecute = TestGame
                        }
                    },
                    {
                        "G", new MenuItem()
                        {
                            Title = "Start from saved Game",
                            //CommandToExecute = RunFromFile
                            CommandToExecute = savedGamesMenu.Run
                        }
                    },
                    {
                        "C", new MenuItem()
                        {
                            Title = "Add custom game settings",
                            CommandToExecute = SaveSettings
                        }
                    }

                }
            };
            
            var menu0 = new Menu(0)
            {
                Title = $"{_settings.GameName} Main Menu",
                MenuItemsDictionary = new Dictionary<string, MenuItem>()
                {
                    {
                        "S", new MenuItem()
                        {
                            Title = "Start game",
                            CommandToExecute = gameMenu.Run
                        }
                    }
                }
            };
            
            menu0.Run();
        }
        
        static string SaveSettings()
        {
            var dbOption = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite("Data Source=/Users/sashazamana17/UniStudies/C#2019/ics0016-2019f/WebConnect4/connect4.db").Options;
            Console.Clear();
                
            var boardWidth = 0;
            var boardHeight = 0;
            var userCanc = false;
            string s;

            (boardWidth, userCanc, s) = Game.GetUserIntInput("Enter board width", 3, 20, 0);
            if (userCanc) return "";

            (boardHeight, userCanc, s) = Game.GetUserIntInput("Enter board height", 3, 20, 0);
            if (userCanc) return "";


            _settings.GameSettingsId = 1;
            _settings.BoardWidth = boardWidth;
            _settings.BoardHeight = boardHeight;

            using (var ctx = new AppDbContext(dbOption))
            {
                InsertDataToDb(ctx);
            }
            
            //GameConfigHandler.SaveConfig(Settings);
            
            return "";
        }
        static void InsertDataToDb(AppDbContext ctx)
        {
            if (_settings.GameSettingsId == 1)
            {
                var defSettings = ctx.GameSettingses.First(item => item.GameSettingsId == 1);
                defSettings.BoardHeight = _settings.BoardHeight;
                defSettings.BoardWidth = _settings.BoardWidth;
                ctx.GameSettingses.Update(defSettings);
            }
            else
            {
                ctx.GameSettingses.Add(new GameSettings()
                {
                    BoardHeight = _settings.BoardHeight,
                    BoardWidth = _settings.BoardWidth,
                    SaveName = _settings.SaveName,
                    SerializedBoard = _settings.SerializedBoard
                });
            }
            
            ctx.SaveChanges();
        }
        static void SetDefaultSettings()
        {
            var dbOption = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite("Data Source=/Users/sashazamana17/UniStudies/C#2019/ics0016-2019f/WebConnect4/connect4.db").Options;
            using (var ctx = new AppDbContext(dbOption))
            {
                if (!ctx.GameSettingses.Any(item => item.GameSettingsId == 1))
                {
                    ctx.Add(new GameSettings()
                    {
                        BoardHeight = 4,
                        BoardWidth = 4,
                        GameName = "Connect4"
                    });
                    ctx.SaveChanges();
                }
                
                _settings = ctx.GameSettingses.First(item => item.GameSettingsId == 1);
            }
        }

        static string TestGame()
        {
            var game = new Game(_settings);
            var done = false;
            do
            {
                Console.Clear();
                GameUI.PrintBoard(game);

                var userXint = 0;
                var Yint = _settings.BoardHeight - 1;

                var userCanceled = false;
                string save = "";
                (userXint, userCanceled, save) = Game.GetUserIntInput("Enter X coordinate or enter S to save", 1, _settings.BoardWidth, 0);
                
                if (userCanceled)
                {
                    done = true;
                    SetDefaultSettings();
                }
                else
                {
                    if (save == "s")
                    {
                        done = false;
                        //Translate(game);
                        Console.WriteLine(SaveGame(game));
                    }
                    else
                    {
                        if (userXint > _settings.BoardWidth || userXint < 0)
                        {
                            Console.WriteLine("X is not valid");
                        }
                        else
                        {
                            done = game.Move(Yint, userXint - 1);
                            
                        }
                    }
                    
                }
            } while (!done);
            
            Console.WriteLine();
            Console.WriteLine("***** Game Over! *****");
            
            return "";
        }

        public static GameSettings LoadSavedGame(string gameName)
        {
            var dbOption = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite("Data Source=/Users/sashazamana17/UniStudies/C#2019/ics0016-2019f/WebConnect4/connect4.db").Options;
            GameSettings res;

            using (var ctx = new AppDbContext(dbOption))
            {
                var gameSettings = ctx.GameSettingses.First(item => item.SaveName == gameName);
                
                if (gameSettings == null)
                {
                    res = ctx.GameSettingses.First(item => item.GameSettingsId == 1);
                    res.SaveName = "No game found with the following name. The new game is started";
                }
                else
                {
                    gameSettings.StartingBoard = JsonConvert.DeserializeObject<CellState[,]>(gameSettings.SerializedBoard);
                    res = gameSettings;
                }
            }

            return res;
        }
        
        static string SaveGame(Game game)
        {
            Console.Clear();
            var dbOption = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite("Data Source=/Users/sashazamana17/UniStudies/C#2019/ics0016-2019f/WebConnect4/connect4.db").Options;

            string gameName;
            var exit = false;

            do
            {
                bool userCancelled;
                
                (gameName, userCancelled) =
                    Game.GetUserStringInput("Please input the name for the game to be saved:", 0);

                if (userCancelled) return "";

                if (gameName.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) == -1)
                {
                    var time = (DateTime.Now);
                    var timeStamp = time.ToString("yy-MM-dd HH-mm");
                    var jsonBoard = JsonConvert.SerializeObject(game.GetBoard());

                    GameSettings newSave = new GameSettings()
                    {
                        SerializedBoard = jsonBoard,
                        SaveName = gameName + $" {timeStamp}",
                        BoardHeight = _settings.BoardHeight,
                        BoardWidth = _settings.BoardWidth
                    };

                    _settings = newSave;

                    using (var ctx = new AppDbContext(dbOption))
                    {
                        InsertDataToDb(ctx);
                    }

                    //GameConfigHandler.SaveGame(newSave);
                    exit = true;
                }
            } while (!exit);

            return $"The game {gameName} was successfully saved.";
        }
    }
}