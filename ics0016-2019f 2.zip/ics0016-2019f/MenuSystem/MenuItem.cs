using System;

namespace MenuSystem
{
    public class MenuItem
    {

        private string ? _title;

        public string ? Title
        {
            get => _title;
            set => _title = Validate(value, 1, 100, false);
        }


        // reference to an method, which returns a string and takes no parameters
        // func<...parameter types..., return type>
        public Func<string>?  CommandToExecute { get; set; }
        
        public static string Validate(string ? item, int minLength, int maxLength, bool toUpper)
        {
            item = item?.Trim();
            if (toUpper)
            {
                item = item?.ToUpper();
            }

            if (!(item?.Length < minLength) && !(item?.Length > maxLength)) return item;
            if (minLength != maxLength)
            {
                throw new ArgumentException(
                    $"String is not correct length (" +
                    $"{minLength}-{maxLength} symbols)! Got " +
                    $"{item.Length} characters.");
            }
            else
            {
                throw new ArgumentException(
                    $"String is not correct length (" +
                    $"{minLength} symbol(s))! Got " +
                    $"{item.Length} characters.");
            }

        }

        public override string ? ToString()
        {
            return Title;
        }
    }
}