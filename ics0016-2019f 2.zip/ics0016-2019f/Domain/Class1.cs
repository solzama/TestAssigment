﻿using System;

namespace Domain
{
    public class Class1
    {
    }
}