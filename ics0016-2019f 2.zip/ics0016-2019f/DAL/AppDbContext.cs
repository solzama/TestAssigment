﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging;
using GameEngine;

namespace DAL
{
    public class AppDbContext : DbContext
    {
        public AppDbContext()
        {
            
        }
    
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options)
        {
        }
        public DbSet<GameSettings> GameSettingses { get; set; }= default!;
        
        private static readonly ILoggerFactory MyLoggerFactory
            = LoggerFactory.Create(builder => { builder.AddConsole(); });
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<GameSettings>(entity =>
            {
                base.OnModelCreating(modelBuilder);
                entity.HasKey(g => g.GameSettingsId);
                entity.Property(g => g.GameName)
                    .HasDefaultValue("Connect 4");
                entity.Property(g => g.BoardHeight)
                    .HasDefaultValue(4);
                entity.Property(g => g.BoardWidth)
                    .HasDefaultValue(4);
            });
        }

       /*protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
         base.OnConfiguring(optionsBuilder);
            optionsBuilder
                .UseLoggerFactory(MyLoggerFactory)
                .UseSqlite("Data Source=/Users/sashazamana17/UniStudies/C#2019/ics0016-2019f/ConsoleApp/connect4.db");
        }*/
    }
    
}