using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GameEngine
{
    public class GameSettings
    {
        
        public int GameSettingsId { get; set; }
        
        [Required] 
        [MaxLength(255)]
        public string GameName { get; set; } = "Connect4";
        
        [Required] 
        public int BoardHeight { get; set; } = 6;
        
        [Required] 
        public int BoardWidth { get; set; } = 7;
        
        [MaxLength(255)]
        public string? SaveName { get; set; }
        
        [NotMapped]
        public CellState[,]? StartingBoard { get; set; }
        
        [MaxLength(255)]
        public string? SerializedBoard { get; set; }
    }
}