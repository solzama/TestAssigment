/*using System;

namespace GameEngine
{
    [Serializable]
    public class GameState
    {
        public string GameSaveName { get; set; } = "Empty Game";

        public Game SavedGame { get; set; } = new Game(GameConfigHandler.LoadConfig());

        public CellState[,] SavedBoard { get; set; } = default!;
    }
}*/