﻿using System;
//using System.Text.Json;

namespace GameEngine
{
    /// <summary>
    /// Connect4
    /// </summary>
    public class Game
    {
        // null, X, O
        private int layer = 0;

        public int BoardWidth { get; }
        public int BoardHeight { get; }
        
        private CellState[,] Board { get;  set; }
        
        public string GameName { get; set; }
        
        
        private bool _playerZeroMove;
        
        public Game(GameSettings settings)
        {
            if (settings.BoardHeight < 4 || settings.BoardWidth < 4)
            {
                throw new ArgumentException("Board size has to be at least 4x4!");
            }
            
            BoardHeight = settings.BoardHeight;
            BoardWidth = settings.BoardWidth;

            GameName = settings.SaveName ?? "";

            Board = settings.StartingBoard ?? new CellState[BoardHeight, BoardWidth];
        }

        
        public CellState[,] GetBoard()
        {
            var result = new CellState[BoardHeight, BoardWidth];
            Array.Copy(Board, result, Board.Length);
            return result;
        }
        
        
        public bool Move(int posY, int posX)
        {
            layer = 0;
            bool done = false;
            bool won = false;
            int count = 0;
            int i = posY;
            if (Board[posY, posX] != CellState.Empty)
            {
                while (i >= 0)
                {
                    if (Board[i, posX] != CellState.Empty)
                    {
                        layer++;
                    }
                    i = i - 1;
                }
            }
            posY = posY - layer;
            if (posY < 0)
            {
                layer = 0;
                Console.WriteLine("Choose different row!");
            }
            else
            {
                for (int xIn = 0; xIn < BoardWidth; xIn++)
                {
                    for (int yIn = 0; yIn < BoardHeight; yIn++)
                    {
                        if (Board[yIn, xIn] != CellState.Empty)
                        {
                            count++;
                        }
                    }
                }
                
                if (count >= (BoardWidth * BoardHeight)-1)
                {
                    Board[posY, posX] = _playerZeroMove ? CellState.Ball : CellState.Heart;
                    done = true;
                }
                else
                {
                    Board[posY, posX] = _playerZeroMove ? CellState.Ball : CellState.Heart;
                    _playerZeroMove = !_playerZeroMove;
                    won = CheckWinningCondition(posY, posX);
                    string item = _playerZeroMove ? "♡" : "◯";
                    if (won == true)
                    {
                        Console.WriteLine("***** The Game is won by " + item + " *****");
                        done = true;
                    }
                }
            }
            
            return done;
        }

        public bool CheckWinningCondition(int lastY, int lastX)
        {
            bool won = false;
            CellState current = _playerZeroMove ? CellState.Heart : CellState.Ball;
            
                int winCount = 1;
                winCount = CheckLeft(winCount);
                if (winCount < 4) winCount = CheckRight(winCount);
                else won = true;
                if (winCount < 4)
                {
                    winCount = 1;
                    winCount = CheckBottom(winCount);
                }
                else
                {
                    won = true;
                }
                if (winCount < 4)
                {
                    winCount = 1;
                    winCount = CheckLeftTopDiagonal(winCount);
                    if (winCount < 4) winCount = CheckRightBottomDiagonal(winCount);
                    else won = true;
                }
                else
                {
                    won = true;
                }
                if (winCount < 4)
                {
                    winCount = 1;
                    winCount = CheckRightTopDiagonal(winCount);
                    if (winCount < 4) winCount = CheckLeftBottomDiagonal(winCount);
                    else won = true;
                }
                else
                {
                    won = true;
                }

                if (winCount == 4) won = true;
                
                int CheckLeft(int _winCount) //5-(5-1)=1
                {
                    int arrayEdge = 0;
                    arrayEdge = BoardWidth - (BoardWidth - lastX);// 4-(4-3)=3-> we need to check only 1 sell
                    
                    for (int i = 0; i < arrayEdge; i++)
                    {
                        if (Board[lastY, lastX - i - 1] == current) //left
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
                
                int CheckRight(int _winCount) //5-1-1=3 //wincount=1
                {
                    int arrayEdge = 0;
                    arrayEdge = BoardWidth - lastX - 1;// 5-1-1=3 -> we need to check 3 cells
                    
                    for (int i = 0; i < arrayEdge; i++)
                    {
                        if (Board[lastY, lastX + i + 1] == current)//right 
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
                
                int CheckBottom(int _winCount) //wincount=1 5-2-1=2
                {
                    int arrayEdge = 0;
                    arrayEdge = BoardHeight - lastY - 1;//5-4-1=0->we need to check 0 cells
                    
                    for (int i = 0; i < arrayEdge; i++)//2
                    {
                        if (Board[lastY + i, lastX] == current) //down 
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
              
                int CheckLeftTopDiagonal(int _winCount) //wincount=1
                {
                    int arrayEdge = 0;
                    if (lastX <= lastY) {arrayEdge = lastX;} // <--
                    if (lastX > lastY) {arrayEdge = lastY;}//
                    
                    for (int i = 0; i < arrayEdge; i++)//2
                    {
                        if (Board[lastY - i - 1, lastX - i - 1] == current)//left-top-diagonal
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
                int CheckLeftBottomDiagonal(int _winCount)
                {
                    int arrayEdge = 0;
                    if (lastX <= BoardHeight - lastY - 1) {arrayEdge = lastX;}
                    if (lastX > BoardHeight - lastY - 1) {arrayEdge = BoardHeight - lastY - 1;}
                    
                    for (int i = 0; i < arrayEdge; i++)//2
                    {
                        if (Board[lastY + i + 1, lastX - i - 1] == current)//left-bottom-diagonal
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
                int CheckRightBottomDiagonal(int _winCount)//??
                {
                    int arrayEdge = 0;
                    if (lastX >= lastY) {arrayEdge = BoardWidth - lastX - 1;}
                    if (lastX < lastY) {arrayEdge = BoardHeight - lastY - 1;}
                    
                    for (int i = 0; i < arrayEdge; i++)//2
                    {
                        if (Board[lastY + i + 1, lastX + i + 1] == current)//right-bottom-diagonal
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
                int CheckRightTopDiagonal(int _winCount)//
                {
                    int arrayEdge = 0;
                    if (lastY <= BoardWidth - lastX - 1) {arrayEdge = lastY;}
                    if (lastY > BoardWidth - lastX - 1) {arrayEdge = BoardWidth - lastX - 1;}
                    
                    for (int i = 0; i < arrayEdge; i++)//2
                    {
                        if (Board[lastY - i - 1, lastX + i + 1] == current)//right-top-diagonal
                        {
                            _winCount++;
                        }
                    }
                    return _winCount;
                }
                
            return won;
        }
        public static (string result, bool wasCanceled) GetUserStringInput(string prompt, int exitIntValue)
        {
            do
            {
                Console.WriteLine(prompt);
                
                Console.WriteLine($"*** To exit the input prompt press {exitIntValue}");

                Console.Write(">");
                
                var inputLine = Console.ReadLine();

                if (int.TryParse(inputLine, out var userInt))
                {
                    if (userInt == exitIntValue) return ("", true);
                }

                return (inputLine, false);
            } while (true);
        }
        public static (int result, bool wasCanceled, string save) GetUserIntInput(string prompt, int min, int max,
            int ? cancelIntValue = null, string cancelStrValue = "")
        {
            do
            {
                Console.WriteLine(prompt);
                if (cancelIntValue.HasValue || !string.IsNullOrWhiteSpace(cancelStrValue))
                {
                    Console.WriteLine($"To cancel input enter: {cancelIntValue}" +
                                      $"{(cancelIntValue.HasValue && !string.IsNullOrWhiteSpace(cancelStrValue) ? " or " : "")}" +
                                      $"{cancelStrValue}");
                }
                Console.Write(">");
                var consoleLine = Console.ReadLine();

                if (consoleLine == "s" || consoleLine == "S") return (0, false, "s");

                if (consoleLine == cancelStrValue) return (0, true, "");

                if (int.TryParse(consoleLine, out var userInt))
                {
                    return userInt == cancelIntValue ? (userInt, true, "") : (userInt, false, "");
                }

                Console.WriteLine($"'{consoleLine}' cant be converted to int value!");
            } while (true);
        }
    }
}