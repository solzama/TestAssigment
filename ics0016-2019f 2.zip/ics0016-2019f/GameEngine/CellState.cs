namespace GameEngine
{
    public enum CellState
    {
        Empty, 
        Heart,
        Ball
    }
    
}