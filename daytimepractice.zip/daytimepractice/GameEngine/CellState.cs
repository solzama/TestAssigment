namespace GameEngine
{
    public enum CellState
    {
        Empty, 
        X,
        O
    }
    
}