namespace GameEngine
{
    public enum CellState
    {
        Empty, 
        R,
        Y
    }
    
}